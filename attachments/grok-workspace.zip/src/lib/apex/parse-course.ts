import { fallbackStructure, type DraftCourse } from "./chunk";
import { SAMPLE_CIT102 } from "./sample-cit102";
import { assignChunksToTopics } from "./retrieval/chunking";
import { chatJson, extractJsonObject } from "./ai/service.server";

function asString(v: unknown, fallback = ""): string {
  return typeof v === "string" && v.trim() ? v.trim() : fallback;
}

export function sampleAsDraft(): DraftCourse {
  return {
    code: SAMPLE_CIT102.code,
    title: SAMPLE_CIT102.title,
    chapters: SAMPLE_CIT102.chapters.map((ch) => ({
      title: ch.title,
      topics: ch.topics.map((t) => ({
        title: t.title,
        summary: t.summary,
        keyIdeas: t.keyIdeas,
      })),
    })),
  };
}

export async function structureFromText(input: {
  text: string;
  hintCode?: string;
  hintTitle?: string;
}): Promise<DraftCourse> {
  const clipped = input.text.slice(0, 24_000);
  const ai = await chatJson({
    maxTokens: 2200,
    feature: "course-map",
    system: `You extract a course map from a student's uploaded material.
Do not invent chapters or topics that are not evidenced in the text.
Prefer the document's own headings. If headings are weak, group by coherent subjects that actually appear.
Return JSON only with shape:
{"code":"string","title":"string","chapters":[{"title":"string","topics":[{"title":"string","summary":"string","keyIdeas":["string"]}]}]}
Rules: at most 10 chapters, at most 6 topics each. Summaries are 2-3 grounded sentences. keyIdeas are short.`,
    user: `Hint code: ${input.hintCode || "(none)"}
Hint title: ${input.hintTitle || "(none)"}

SOURCE:
${clipped}`,
  });

  if (ai.ok) {
    try {
      const parsed = extractJsonObject(ai.text) as {
        code?: unknown;
        title?: unknown;
        chapters?: Array<{
          title?: unknown;
          topics?: Array<{ title?: unknown; summary?: unknown; keyIdeas?: unknown }>;
        }>;
      };
      const chapters = (parsed.chapters ?? [])
        .map((ch) => ({
          title: asString(ch.title, "Chapter"),
          topics: (ch.topics ?? [])
            .map((t) => ({
              title: asString(t.title),
              summary: asString(t.summary),
              keyIdeas: Array.isArray(t.keyIdeas)
                ? t.keyIdeas.filter((x): x is string => typeof x === "string").slice(0, 8)
                : [],
            }))
            .filter((t) => t.title)
            .slice(0, 6),
        }))
        .filter((ch) => ch.topics.length)
        .slice(0, 10);
      if (chapters.length) {
        return {
          code: asString(parsed.code, input.hintCode || "COURSE"),
          title: asString(parsed.title, input.hintTitle || "Untitled course"),
          chapters,
        };
      }
    } catch {
      // fall through
    }
  }

  return fallbackStructure(input.text, { code: input.hintCode, title: input.hintTitle });
}

export function materialChunks(draft: DraftCourse, raw: string) {
  return assignChunksToTopics(draft, raw);
}
