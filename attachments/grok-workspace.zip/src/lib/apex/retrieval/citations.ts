import type { Chunk, RetrievalCandidate, SourceCitation } from "./types";

export function citationLabel(chunk: Chunk): string {
  const source = chunk.sourceName?.replace(/\.[a-z0-9]+$/i, "") || "Source";
  if (chunk.page != null) return `[${source} — p. ${chunk.page}]`;
  if (chunk.heading) return `[${source} — ${chunk.heading}]`;
  return `[${source}]`;
}

export function toCitation(chunk: Chunk): SourceCitation {
  const locator = chunk.page != null ? `p. ${chunk.page}` : chunk.heading || "source";
  return {
    chunkId: chunk.id,
    documentId: chunk.documentId,
    sourceName: chunk.sourceName || "Source",
    page: chunk.page,
    heading: chunk.heading,
    topicTitle: chunk.topicTitle,
    chapterTitle: chunk.chapterTitle,
    locator,
    label: citationLabel(chunk),
    excerpt: chunk.content.trim().slice(0, 420),
  };
}

export function formatContext(selected: RetrievalCandidate[]): string {
  if (!selected.length) return "(No source excerpts retrieved.)";
  return selected
    .map((c, i) => {
      const loc = c.chunk.page != null ? `p. ${c.chunk.page}` : c.chunk.heading || "source";
      const topic = c.chunk.topicTitle ? ` · ${c.chunk.topicTitle}` : "";
      return `[${i + 1} ${c.chunk.sourceName || "Source"} — ${loc}${topic}]\n${c.chunk.content.trim()}`;
    })
    .join("\n\n");
}

export function formatCitationLine(citations: SourceCitation[]): string {
  if (!citations.length) return "";
  const seen = new Set<string>();
  const labels: string[] = [];
  for (const c of citations) {
    if (seen.has(c.label)) continue;
    seen.add(c.label);
    labels.push(c.label);
  }
  return labels.join(" ");
}
