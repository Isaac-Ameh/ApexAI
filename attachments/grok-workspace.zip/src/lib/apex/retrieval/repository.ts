import type { Sql } from "@/lib/db";
import { estimateTokens } from "./math";
import type { Chunk } from "./types";

type ChunkRow = {
  id: number;
  course_id: number;
  document_id: number | null;
  chapter_id: number | null;
  topic_id: number | null;
  page: number | null;
  heading: string | null;
  chunk_index: number | null;
  chunk_uid: string | null;
  content: string;
  token_estimate: number | null;
  topic_title: string | null;
  chapter_title: string | null;
  source_name: string | null;
};

function toChunk(row: ChunkRow): Chunk {
  return {
    id: row.id,
    uid: row.chunk_uid || `chunk:${row.course_id}:${row.id}`,
    courseId: row.course_id,
    documentId: row.document_id,
    chapterId: row.chapter_id,
    topicId: row.topic_id,
    page: row.page,
    heading: row.heading,
    chunkIndex: row.chunk_index ?? 0,
    content: row.content,
    tokenEstimate: row.token_estimate ?? estimateTokens(row.content),
    topicTitle: row.topic_title,
    chapterTitle: row.chapter_title,
    sourceName: row.source_name,
  };
}

export async function loadCourseChunks(
  sql: Sql,
  userId: string,
  courseId: number,
): Promise<Chunk[]> {
  const rows = await sql<ChunkRow>`
    select
      c.id,
      c.course_id,
      c.document_id,
      coalesce(c.chapter_id, t.chapter_id) as chapter_id,
      c.topic_id,
      c.page,
      c.heading,
      c.chunk_index,
      c.chunk_uid,
      c.content,
      c.token_estimate,
      t.title as topic_title,
      ch.title as chapter_title,
      coalesce(d.name, cr.source_name) as source_name
    from source_chunks c
    left join topics t on t.id = c.topic_id
    left join chapters ch on ch.id = coalesce(c.chapter_id, t.chapter_id)
    left join source_documents d on d.id = c.document_id
    left join courses cr on cr.id = c.course_id
    where c.user_id = ${userId} and c.course_id = ${courseId}
    order by c.id
  `;
  return rows.map(toChunk);
}
