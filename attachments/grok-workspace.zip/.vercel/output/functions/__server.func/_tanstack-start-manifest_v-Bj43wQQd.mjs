//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bj43wQQd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/login",
			"/courses/$courseId",
			"/courses/new",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-CNlgWYhb.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/dist-Yt69c636.js",
			"/assets/createServerFn-sLccmepz.js",
			"/assets/link-BnqV1kx9.js",
			"/assets/preload-helper-Czpn1I53.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CNlgWYhb.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Dgogcs6p.js",
			"/assets/progress-9PRgc7Rw.js",
			"/assets/state-block-C4dyPSXS.js",
			"/assets/button-C8uGuiqq.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-CaHWIuWv.js",
			"/assets/client-6D9voRNy.js",
			"/assets/button-C8uGuiqq.js",
			"/assets/input-Di_RQFka.js"
		]
	},
	"/courses/$courseId": {
		filePath: "/workspace/src/routes/courses/$courseId.tsx",
		children: void 0,
		preloads: [
			"/assets/_courseId-0yMEi7Rc.js",
			"/assets/check-BQ2FHmm9.js",
			"/assets/progress-9PRgc7Rw.js",
			"/assets/state-block-C4dyPSXS.js",
			"/assets/button-C8uGuiqq.js"
		]
	},
	"/courses/new": {
		filePath: "/workspace/src/routes/courses/new.tsx",
		children: void 0,
		preloads: [
			"/assets/new-BgU_9OpG.js",
			"/assets/check-BQ2FHmm9.js",
			"/assets/state-block-C4dyPSXS.js",
			"/assets/button-C8uGuiqq.js",
			"/assets/input-Di_RQFka.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
